package main;
import java.util.ArrayList;
import janela.JanelaAutomato;

import estrutura.*;
public class Main {
	public static void main(String[] args) {
		JanelaAutomato j = new JanelaAutomato();
		j.inicializarTela();
	}

}
