/* Autômato
* VERSÃO: 1.1.10.11
* ULTIMO EDITOR: Lucas
* DATA: 05/06/2019
* HORA: 21:51
*/

#include <iostream>
#include "menu.h"
#include "automato.h"

using namespace std;

int main(){
	deciderMenu();
	return 0;
}
