package thread;

public interface Observador {
	
	void mostrarTabuleiro ( int m[][] );

}
